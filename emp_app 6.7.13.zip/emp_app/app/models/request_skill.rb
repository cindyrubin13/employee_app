class RequestSkill < ActiveRecord::Base
  attr_accessible :language, :project_request_id, :employee_id
end
