Date.weekdays = $w('日 月 火 水 木 金 土');
Date.months = $w('1月 2月 3月 4月 5月 6月 7月 8月 9月 10月 11月 12月');

Date.first_day_of_week = 0

_translations = {
  "OK": "OK",
  "Now": "現在",
  "Today": "今日",
  "Clear": "クリア"
}