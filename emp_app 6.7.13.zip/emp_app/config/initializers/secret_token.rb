# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
EmpApp::Application.config.secret_token = '3bde065d973ee3d9d2faee948f5a83bc58509f690b2fdc2ac8cf109adb468560867d8c1884612eaf6ad0f19646e9270ef014007f4182c64537373146e36cba09'
