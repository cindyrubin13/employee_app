class DashboardController < ApplicationController


  def index
  	@dashboard = Dashboard.new
  end
  def request_report
  	
  end
  def overall_report
  	
  end
   def time_report
  	
  end
  def developer_skill_report
  end
   def average_report
  	
   end 
  def volunteer_report
  	
  end
  def shared_report
  	
  end
   def shared2_report
  	
  end
end
