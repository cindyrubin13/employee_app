module ProjectRequestsHelper


#  def current_skill_with_relevant_skills_per_request(current_skill, relevant_skill) 

 #   @common1_skill = Array.new

   
 #    if !current_skill.nil?
 #       current_skill = current_skill.split(", ")
  #    end
    
    
   # if !relevant_skill.nil?
  #    relevant_skill = relevant_skill.split(", ")
  #  end

 #   @common1_skill = current_skill & relevant_skill
 #   @score_common1 = @common1_skill.length
 #   @common1_skill = @common1_skill.join(", ")


 # end

  #def skills_interested_with_relevant_skills_per_request(interested_skills, relevant_skill) 

   # @common2_skill = Array.new

   
   #  if !interested_skills.nil?
      #  interested_skills = interested_skills.split(", ")
   #   end
    
    
   # if !relevant_skill.nil?
   #   relevant_skill = relevant_skill.split(", ")
  #  end

  #  @common2_skill = interested_skills & relevant_skill
  #  @score_common2 = @common2_skill.length
 #   @common2_skill = @common2_skill.join(", ")


 # end







	
end
