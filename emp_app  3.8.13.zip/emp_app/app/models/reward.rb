class Reward < ActiveRecord::Base
  attr_accessible :employee_id, :level_change, :project_request_id, :reward_date, :reward_points, :skill_id, :response_id
  has_many :employees
  has_many :project_requests
  belongs_to :employees
  belongs_to :project_requests
  belongs_to :responses
end
