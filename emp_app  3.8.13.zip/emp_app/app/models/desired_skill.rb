class DesiredSkill < ActiveRecord::Base
  attr_accessible :language, :employee_id, :level, :skill_id
end
