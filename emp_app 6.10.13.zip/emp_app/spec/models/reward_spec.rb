require 'spec_helper'

describe Reward do
  pending "add some examples to (or delete) #{__FILE__}"
end
