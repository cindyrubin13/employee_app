require 'test_helper'

class ProjectRequestTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
