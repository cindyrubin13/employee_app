require 'test_helper'

class ProjectRequestsHelperTest < ActionView::TestCase
end
