class DeveloperSkill < ActiveRecord::Base
  attr_accessible :language, :employee_id, :level
end
