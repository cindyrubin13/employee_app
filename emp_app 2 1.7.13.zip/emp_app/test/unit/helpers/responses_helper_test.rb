require 'test_helper'

class ResponsesHelperTest < ActionView::TestCase
end
