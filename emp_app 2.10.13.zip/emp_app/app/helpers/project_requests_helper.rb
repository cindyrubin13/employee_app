module ProjectRequestsHelper

#def overlap_count(skills1, skills2)
#  split_skills(skills1, skills2)
#end
#def split_skills(skills1, skills2)
#   skills1 = skills1.split(", ")
#   skills2 = skills2.split(", ")
#   skill_score(skills1, skills2)
#end
#def skill_score(skills1, skills2)
#   # common_skills =  skills1 & skills2
#   skills1 & skills2
#    #common_skills.length
#end






	
end
