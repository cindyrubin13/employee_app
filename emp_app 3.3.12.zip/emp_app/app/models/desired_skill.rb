class DesiredSkill < ActiveRecord::Base
  attr_accessible :language, :employee_id
end
