class DashboardController < ApplicationController


  def index
  	@dashboard = Dashboard.new
  end
  def request_report
  	@dashboard = Dashboard.new
  end
  def overall_report
  	@dashboard = Dashboard.new
  end
   def time_report
  	@dashboard = Dashboard.new
  end
  def developer_skill_report
  	@dashboard = Dashboard.new
  end
   def average_report
  	@dashboard = Dashboard.new
  end

  def volunteer_report
  	@dashboard = Dashboard.new
  end
  def shared_report
  	@dashboard = Dashboard.new
  end
   def shared2_report
  	@dashboard = Dashboard.new
  end
end
