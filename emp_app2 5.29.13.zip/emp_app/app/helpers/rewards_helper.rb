module RewardsHelper


	

end
