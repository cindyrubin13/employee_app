Date.weekdays = $w("Po Út St Čt Pá So Ne");
Date.months = $w("Leden Únor Březen Duben Květen Červen Červenec Srpen Září Říjen Listopad Prosinec" );

Date.first_day_of_week = 1

_translations = {
    "OK": "OK",
    "Now": "Teď",
    "Today": "Dnes",
    "Clear": "Smazat"
}