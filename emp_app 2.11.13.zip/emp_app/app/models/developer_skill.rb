class DeveloperSkill < ActiveRecord::Base
  attr_accessible :language, :employee_id
end
